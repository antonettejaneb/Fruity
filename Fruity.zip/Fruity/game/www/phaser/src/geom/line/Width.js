var Width = function (line)
{
    return Math.abs(line.x1 - line.x2);
};

module.exports = Width;
